# JavaFinalProject

Collaborators : Yves-alain Agbodjogbe and Nicolas Zambrano

Git Pages address : https://agbodjogbeyves-alain.github.io

Warning : little problem with the index on git pages we have the class HighScores1 but you must click on Tree on git pages to see that. We try to fix this problem
